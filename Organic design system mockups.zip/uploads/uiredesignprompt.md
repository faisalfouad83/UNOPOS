Redesign the visual UI of UNOPOS, a Flutter POS + business-management app for supermarkets/hypermarkets (multi-tenant SaaS, runs on Windows desktop and Android, Material 3, must support both LTR English and RTL Arabic — the app already uses the Cairo font for both).

Before writing any code, load the `frontend-design` and `ui-ux-pro-max` skills and propose 2-3 distinct visual directions (mood, palette, typography treatment) with a short rationale for each — this is a working point-of-sale tool used all day on a shop counter, not a marketing site, so favor clarity and fast legibility over trend-chasing. Wait for me to pick a direction before implementing.

Current design system lives entirely in `lib/core/theming/app_theme.dart` (light/dark ColorScheme, one shared text theme, component themes for cards/buttons/inputs/nav). Brand colors are exposed via a `BrandColors` class for the few places that need a direct accent outside the semantic ColorScheme roles. Once a direction is picked, redesign should happen primarily in this one file plus any component-level widget polish needed to fully express it — not a rewrite of business logic or navigation structure.

Screens/modules in scope (all under `lib/features/*/presentation/`): activation, store/manager onboarding, tile picker + PIN pad, dashboard, POS/checkout, inventory, debts, suppliers, accounting, HR, reports, settings, developer console, notifications.

Constraints:
- Keep Material 3 (`useMaterial3: true`) and the existing ColorScheme role structure — swap values/tokens, don't rip out the system.
- Must still pass in both light and dark mode.
- Must still render correctly in RTL (Arabic) — verify at least one screen in Arabic locale after changes.
- Don't touch any repository, provider, or business-logic files — visual/theming layer only.
- Run `flutter analyze` clean at the end.
