# Handoff: UNOPOS Visual Redesign

## Overview
Visual reskin of UNOPOS, a Flutter POS + business-management app for supermarkets/hypermarkets (multi-tenant SaaS, Windows desktop + Android, Material 3, LTR English + RTL Arabic). This bundle covers all 14 screens/modules named in the original spec, redesigned on the **Organic** design system (warm cream/terracotta, Caprasimo display type over Figtree body, pill buttons, soft rounded shapes).

## About the Design Files
The files in `screens/` are **design references built in HTML** — interactive prototypes showing the intended look, states, and RTL/dark-mode behavior. They are NOT production code to copy into the Flutter app. The task for the developer is to **recreate this visual design inside the existing Flutter codebase**, primarily by editing `lib/core/theming/app_theme.dart` (the light/dark `ColorScheme`, shared `TextTheme`, and component themes) plus the `BrandColors` class, per the constraints below — not a UI rewrite.

Each `.dc.html` file is self-contained-ish (loads `organic.css` + inline React-style logic) and has a Light/Dark, EN/AR, and Desktop/Tablet toggle in its top toolbar — use these to see every state before implementing.

## Fidelity
**High-fidelity.** Colors, type, spacing, and component shapes are final per the Organic design system tokens (see `organic-readme.md` and `screens/organic.css`). Copy/content is realistic placeholder data (product names, prices, staff names) — replace with real data bindings, not hardcoded strings.

## Design system source of truth
`screens/organic.css` is the token sheet — **take every color, font, spacing, and radius value from its CSS variables**, don't eyeball pixel values off screenshots. Key tokens:
- `--color-bg` #f5ead8 (light) / `--color-bg` #201c17 (dark, via `[data-theme="dark"]`)
- `--color-text`, `--color-surface`, `--color-accent` #c67139 (terracotta), `--color-accent-2` #7a8a5e (sage) — each with a 100–900 ramp
- `--font-heading` (Caprasimo), `--font-body` (Figtree)
- `--radius-md/lg`, `--shadow-sm/md/lg`, `--space-*`
- Component classes: `.btn` (`.btn-primary/-secondary/-ghost`), `.tag`, `.card`, `.input`, `.table`

In Flutter terms: `--color-bg`/`--color-surface`/`--color-text`/`--color-accent` map to `ColorScheme.surface/surfaceVariant/onSurface/primary`; the tonal ramps map to Material 3's tonal palette generation. Dark mode is a second token set (see `[data-theme="dark"]` block in `organic.css`), not a computed inverse — port both explicitly.

## Screens / Views
All 14 screens in `screens/`, each with Theme (Light/Dark) · Language (EN/AR) · Device (Desktop/Tablet) toggles baked into the file itself:

1. **UNOPOS Activation.dc.html** — License key entry to activate a device. Single centered card, no sidebar.
2. **UNOPOS Onboarding.dc.html** — Store/manager setup wizard (4-step progress bar: License → Business → Inventory → Team). Single centered card.
3. **UNOPOS Tile Picker + PIN Pad.dc.html** — Staff tile picker (grid of profile tiles) → PIN pad on selection. Two-panel layout: brand/date panel (38% width) + content panel.
4. **UNOPOS Dashboard.dc.html** — KPI cards, weekly sales bar chart, low-stock list, recent-transactions table. Sidebar nav + content.
5. **UNOPOS POS Checkout.dc.html** — Product grid with category chips + cart panel with totals and Cash/Card actions. Sidebar + content + right-side cart panel.
6. **UNOPOS Inventory.dc.html** — KPI cards + product table (SKU, stock, price, status tags).
7. **UNOPOS Debts.dc.html** — KPI cards + customer credit table (amount, due date, status).
8. **UNOPOS Suppliers.dc.html** — Card grid of supplier accounts (status tag, balance).
9. **UNOPOS Accounting.dc.html** — KPI cards (revenue/expenses/margin) + recent-expenses table.
10. **UNOPOS HR.dc.html** — Card grid of staff (avatar initials, role tag, shift).
11. **UNOPOS Reports.dc.html** — Sales trend bar chart + top-products list + KPI cards.
12. **UNOPOS Settings.dc.html** — Card grid of setting sections (store profile, tax/currency, users, receipt template, language/region, backup/sync).
13. **UNOPOS Developer Console.dc.html** — Sync/device KPI cards + monospace sync log list.
14. **UNOPOS Notifications.dc.html** — List of notification cards (kind tag, title, body, timestamp, unread dot).

### Shared layout pattern (screens 4–13)
- **Sidebar** (196px desktop / 60px tablet, `var(--color-surface)` background): logo mark (28px accent-square with Arabic "ن" glyph, bold, `'Segoe UI',Tahoma,Arial,sans-serif`) + 9 nav items (Dashboard, POS/Checkout, Inventory, Debts, Suppliers, Accounting, HR, Reports, Settings), each a 24px inline SVG icon (stroke-width 1.8, `currentColor`) + label; active item gets `--color-accent-200` background and `--color-accent-800` text/icon color. On tablet, labels hide and only icons show.
- **Content area**: page title (`--font-heading`, 18px) + subtitle, then KPI card row (`.card.elev-sm`, grid, `--card-kicker` label + heading-font value), then a data table (`.table`) or card grid depending on screen.
- **Frame**: whole screen renders inside a fixed-size rounded frame (1160×680 desktop / 860×640 tablet) with `box-shadow: 0 12px 32px rgba(0,0,0,.18)` — this is a mockup device frame for presentation only; the real app is full-window, not a card.

### RTL behavior
Every screen sets `dir="rtl"` and swaps all copy to Arabic when the AR toggle is active; layout mirrors (sidebar/cart panel flip sides). Arabic numerals use Eastern Arabic digits (٠١٢٣...) throughout, matching how the app should localize numbers, not just strings.

### Dark mode implementation note (important)
Dark mode is applied via `data-theme="dark"` on the screen's outer frame div, which re-scopes the CSS custom properties. Because CSS `color` doesn't re-inherit through a changed custom property on an element that didn't itself set `color`, **the frame wrapper explicitly sets `color: var(--color-text)`** — without this, text goes on rendering in the light-mode color even under `data-theme="dark"`. Flutter's `ColorScheme`/`Theme.of(context)` inheritance won't have this specific pitfall, but it's a good reminder to verify every text style actually resolves from the active `ColorScheme`, not a cached/inherited value.

## Interactions & Behavior
- Nav item click → navigate to that module (not wired in the mockup beyond visual active state).
- Tile picker: tapping a staff tile → advances to PIN pad step, shows that staff's avatar/name.
- PIN pad: numeric keypad 1–9, blank, 0, ⌫ (backspace); dots above indicate PIN length entered (mockup shows 3/6 filled as a static example).
- POS Checkout: category chips filter the product grid (visual only in mockup); tapping a product tile would add to cart.
- Cards/tables have no special hover states specified beyond the design system's built-in `.btn`/`.card` hover/focus treatment (see `organic-readme.md` → Interaction states) — reuse those, don't invent new ones.
- No loading/error/empty states were designed in this pass — flag to the design owner if the real app needs them before build.

## State Management
Not applicable — these are static visual mockups. The real implementation should bind each screen to its existing providers/repositories (per the original spec: **do not touch repository, provider, or business-logic files** — this redesign is theming/visual layer only).

## Design Tokens
See `screens/organic.css` for the authoritative source. Summary:
- **Colors**: `--color-bg` #f5ead8 / dark #201c17; `--color-text` #201e1d / dark #f3ece0; `--color-accent` #c67139; `--color-accent-2` #7a8a5e; each with generated 100–900 OKLCH ramps.
- **Type**: `--font-heading` Caprasimo, `--font-body` Figtree.
- **Radius**: `--radius-md`, `--radius-lg` (pill radius 999px for buttons/inputs).
- **Shadow**: `--shadow-sm/md/lg`.
- **Spacing**: `--space-*` scale, density 1.10×.

## Assets
No custom image assets — all "photo" placeholders in POS product tiles are a diagonal-stripe CSS pattern standing in for real product photography (wrap real photos in the design system's `.washed` treatment per `organic-readme.md`). The logo mark is a plain CSS square (accent-colored, rounded) with an Arabic "ن" glyph — no icon file to source. Nav icons are inline SVGs (paths included directly in each screen's markup).

## Files
```
design_handoff_unopos_redesign/
├── README.md                                  (this file)
├── organic-readme.md                          (Organic design-system guide)
└── screens/
    ├── organic.css                            (design tokens + component CSS — load this first)
    ├── UNOPOS Activation.dc.html
    ├── UNOPOS Onboarding.dc.html
    ├── UNOPOS Tile Picker + PIN Pad.dc.html
    ├── UNOPOS Dashboard.dc.html
    ├── UNOPOS POS Checkout.dc.html
    ├── UNOPOS Inventory.dc.html
    ├── UNOPOS Debts.dc.html
    ├── UNOPOS Suppliers.dc.html
    ├── UNOPOS Accounting.dc.html
    ├── UNOPOS HR.dc.html
    ├── UNOPOS Reports.dc.html
    ├── UNOPOS Settings.dc.html
    ├── UNOPOS Developer Console.dc.html
    └── UNOPOS Notifications.dc.html
```
Open any `.dc.html` file directly in a browser to view it — each is self-contained aside from the sibling `organic.css`.

## Using this with Claude Code
1. Unzip this folder into (or alongside) the Flutter repo.
2. Point Claude Code at `lib/core/theming/app_theme.dart` and this README together, and ask it to port the Organic tokens (`screens/organic.css`) into the `ColorScheme`/`TextTheme`/component themes — light and dark — plus `BrandColors`.
3. Open each `.dc.html` screen in a browser (or hand Claude Code a screenshot) as the visual target for that module's widget-level polish.
4. Ask Claude Code to verify RTL (Arabic locale) on at least one screen and run `flutter analyze` clean at the end, per the original constraints.
